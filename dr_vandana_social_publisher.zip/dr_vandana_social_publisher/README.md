# Dr. Vandana Social Publisher — Prototype

Standalone FastAPI prototype for controlled multi-platform publishing.

## Platforms
- Telegram Channel: live-capable
- Telegram Group/Supergroup: live-capable
- Facebook Page: live-capable after Meta credentials/permissions are configured
- WhatsApp Channel: placeholder pending official API verification
- WhatsApp Group: placeholder pending official API verification

## Recommended location

Keep this separate from the production website:

D:\ravishori\
├── dr-vandana-website\
└── dr-vandana-social-publisher\

Do NOT initially copy this into the production website.

## Install

```powershell
cd D:\ravishori\dr-vandana-social-publisher
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

## Safe first run

Keep:

```env
PUBLISH_MODE=mock
```

Then:

```powershell
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open:

http://127.0.0.1:8000

Mock mode never sends a real external post.

## Live Telegram

Configure `.env`:

```env
PUBLISH_MODE=live
TELEGRAM_BOT_TOKEN=...
TELEGRAM_CHANNEL_ID=@your_channel
TELEGRAM_GROUP_ID=-1001234567890
```

Create the bot with Telegram BotFather, add it to the target channel/group, and give it only the required posting permissions.

## Facebook

Configure:

```env
FACEBOOK_PAGE_ID=...
FACEBOOK_PAGE_ACCESS_TOKEN=...
FACEBOOK_GRAPH_API_VERSION=vXX.X
```

Use the currently supported Meta Graph API version and permissions. Never put the token in frontend code.

## WhatsApp

The WhatsApp adapter intentionally returns `not_configured`. WhatsApp Business messaging, Channels and ordinary Groups are separate product/API surfaces. We will implement only the officially supported capability after verifying the exact Meta account configuration.

Do not replace this with unofficial WhatsApp Web automation.

## Production direction

Later:

Website CMS
→ explicit channel checkboxes
→ platform-specific content variants
→ distribution queue
→ provider adapters
→ delivery status/audit log
→ retry/idempotency
→ scheduling
