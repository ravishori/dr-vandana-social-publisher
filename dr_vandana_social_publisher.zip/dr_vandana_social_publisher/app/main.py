from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from app.config import settings
from app.models import PublishRequest
from app.services.publisher import PublisherService

BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

app = FastAPI(title="Dr. Vandana Social Publisher", version="0.1.0")
publisher = PublisherService()

@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={
            "publish_mode": settings.publish_mode,
            "max_message_length": settings.max_message_length,
        },
    )

@app.get("/health")
async def health():
    return {"status": "ok", "publish_mode": settings.publish_mode}

@app.post("/api/preview")
async def preview(payload: PublishRequest):
    if len(payload.message) > settings.max_message_length:
        return {"success": False, "error": "Message exceeds configured limit."}
    return {
        "success": True,
        "message_length": len(payload.message),
        "platforms": payload.platforms,
        "preview": payload.message,
    }

@app.post("/api/publish")
async def publish(payload: PublishRequest):
    if len(payload.message) > settings.max_message_length:
        return {"success": False, "error": "Message exceeds configured limit."}

    results = await publisher.publish(payload.message, payload.platforms)

    return {
        "success": all(item.success for item in results),
        "results": [item.model_dump() for item in results],
    }
