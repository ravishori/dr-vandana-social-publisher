from app.adapters.facebook import FacebookAdapter
from app.adapters.telegram import TelegramAdapter
from app.adapters.whatsapp import WhatsAppAdapter
from app.config import settings
from app.models import PublishResult

class PublisherService:
    def __init__(self):
        self.telegram = TelegramAdapter(settings.telegram_bot_token)
        self.facebook = FacebookAdapter(
            settings.facebook_page_id,
            settings.facebook_page_access_token,
            settings.facebook_graph_api_version,
        )
        self.whatsapp = WhatsAppAdapter()

    async def publish(self, message, platforms):
        results = []

        for platform in platforms:
            if settings.publish_mode == "mock":
                results.append(PublishResult(
                    platform=platform,
                    success=True,
                    status="mock_success",
                    response={"mode": "mock"},
                ))
                continue

            try:
                result = await self._publish_live(platform, message)
                configured = result.get("status") != "not_configured"
                results.append(PublishResult(
                    platform=platform,
                    success=configured,
                    status="published" if configured else "not_configured",
                    provider_message_id=self._message_id(platform, result),
                    response=result,
                ))
            except Exception as exc:
                results.append(PublishResult(
                    platform=platform,
                    success=False,
                    status="failed",
                    error=str(exc),
                ))

        return results

    async def _publish_live(self, platform, message):
        if platform == "telegram_channel":
            return await self.telegram.send_message(
                settings.telegram_channel_id, message
            )
        if platform == "telegram_group":
            return await self.telegram.send_message(
                settings.telegram_group_id, message
            )
        if platform == "facebook":
            return await self.facebook.publish_text_post(message)
        if platform == "whatsapp_channel":
            return await self.whatsapp.send_message("channel", message)
        if platform == "whatsapp_group":
            return await self.whatsapp.send_message("group", message)
        raise ValueError(f"Unsupported platform: {platform}")

    @staticmethod
    def _message_id(platform, result):
        if platform.startswith("telegram"):
            value = result.get("result", {}).get("message_id")
            return str(value) if value is not None else None
        if platform == "facebook":
            value = result.get("id")
            return str(value) if value is not None else None
        return None
