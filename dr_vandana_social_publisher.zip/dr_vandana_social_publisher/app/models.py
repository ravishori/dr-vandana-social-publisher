from typing import Literal
from pydantic import BaseModel, Field

Platform = Literal[
    "facebook",
    "telegram_channel",
    "telegram_group",
    "whatsapp_channel",
    "whatsapp_group",
]

class PublishRequest(BaseModel):
    message: str = Field(min_length=1)
    platforms: list[Platform] = Field(min_length=1)

class PublishResult(BaseModel):
    platform: str
    success: bool
    status: str
    provider_message_id: str | None = None
    error: str | None = None
    response: dict | None = None
