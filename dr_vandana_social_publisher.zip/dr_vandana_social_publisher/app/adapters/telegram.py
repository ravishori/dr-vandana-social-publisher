import httpx

class TelegramAdapter:
    def __init__(self, bot_token: str, timeout: float = 30.0):
        self.bot_token = bot_token
        self.timeout = timeout

    @property
    def base_url(self):
        return f"https://api.telegram.org/bot{self.bot_token}"

    async def send_message(self, chat_id: str, message: str) -> dict:
        if not self.bot_token:
            raise RuntimeError("TELEGRAM_BOT_TOKEN is not configured")
        if not chat_id:
            raise RuntimeError("Telegram destination ID is not configured")

        payload = {
            "chat_id": chat_id,
            "text": message,
            "disable_web_page_preview": False,
        }

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                f"{self.base_url}/sendMessage",
                json=payload,
            )

        if response.is_error:
            try:
                detail = response.json()
            except Exception:
                detail = response.text
            raise RuntimeError(
                f"Telegram API error {response.status_code}: {detail}"
            )

        return response.json()
