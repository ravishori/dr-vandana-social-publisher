import httpx

class FacebookAdapter:
    def __init__(self, page_id, access_token, graph_api_version, timeout=30.0):
        self.page_id = page_id
        self.access_token = access_token
        self.graph_api_version = graph_api_version
        self.timeout = timeout

    async def publish_text_post(self, message: str) -> dict:
        if not self.page_id:
            raise RuntimeError("FACEBOOK_PAGE_ID is not configured")
        if not self.access_token:
            raise RuntimeError("FACEBOOK_PAGE_ACCESS_TOKEN is not configured")

        url = (
            f"https://graph.facebook.com/"
            f"{self.graph_api_version}/{self.page_id}/feed"
        )

        payload = {
            "message": message,
            "access_token": self.access_token,
        }

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(url, data=payload)

        if response.is_error:
            try:
                detail = response.json()
            except Exception:
                detail = response.text
            raise RuntimeError(
                f"Facebook Graph API error {response.status_code}: {detail}"
            )

        return response.json()
