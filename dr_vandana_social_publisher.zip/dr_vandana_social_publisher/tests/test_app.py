from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_preview():
    response = client.post("/api/preview", json={
        "message": "Test",
        "platforms": ["telegram_channel"]
    })
    assert response.status_code == 200
    assert response.json()["success"] is True
