# Integration Checklist

## Prototype
- [ ] Mock mode works
- [ ] Preview works
- [ ] Telegram Channel tested
- [ ] Telegram Group tested
- [ ] Facebook tested on controlled Page
- [ ] WhatsApp official API capability verified

## Security
- [ ] `.env` excluded from Git
- [ ] Tokens never appear in browser
- [ ] Server bound to 127.0.0.1 during prototype
- [ ] No unofficial browser automation
- [ ] Synthetic test data only

## Production
- [ ] Admin authentication
- [ ] RBAC
- [ ] Audit log
- [ ] Secret manager
- [ ] Rate limiting
- [ ] Idempotency
- [ ] Retry policy
- [ ] Platform-specific content variants
- [ ] Approval workflow
- [ ] Scheduling
- [ ] Monitoring
