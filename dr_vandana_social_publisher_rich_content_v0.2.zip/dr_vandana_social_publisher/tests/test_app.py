from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert response.json()["version"] == "0.2.0"


def test_preview_with_link_and_media():
    response = client.post("/api/preview", json={
        "message": "Test article",
        "platforms": ["telegram_channel"],
        "link": "https://example.com/article",
        "media": [{
            "kind": "image",
            "path": "uploads/test.jpg",
            "filename": "test.jpg",
        }],
    })
    assert response.status_code == 200
    assert response.json()["success"] is True
    assert response.json()["media"][0]["kind"] == "image"


def test_preview_rejects_empty_content():
    response = client.post("/api/preview", json={
        "message": "",
        "platforms": ["telegram_channel"],
    })
    assert response.status_code == 200
    assert response.json()["success"] is False
