from pathlib import Path

import httpx


class TelegramAdapter:
    def __init__(self, bot_token: str, timeout: float = 60.0):
        self.bot_token = bot_token
        self.timeout = timeout

    @property
    def base_url(self):
        return f"https://api.telegram.org/bot{self.bot_token}"

    def _check(self, response: httpx.Response):
        if response.is_error:
            try:
                detail = response.json()
            except Exception:
                detail = response.text
            raise RuntimeError(
                f"Telegram API error {response.status_code}: {detail}"
            )
        data = response.json()
        if not data.get("ok", False):
            raise RuntimeError(f"Telegram API error: {data}")
        return data

    async def send_message(self, chat_id: str, message: str) -> dict:
        self._validate(chat_id)
        payload = {
            "chat_id": chat_id,
            "text": message,
            "disable_web_page_preview": False,
        }
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(f"{self.base_url}/sendMessage", json=payload)
        return self._check(response)

    async def send_media(
        self,
        chat_id: str,
        kind: str,
        path: str,
        caption: str = "",
    ) -> dict:
        self._validate(chat_id)
        endpoint_map = {
            "image": "sendPhoto",
            "video": "sendVideo",
            "document": "sendDocument",
        }
        field_map = {
            "image": "photo",
            "video": "video",
            "document": "document",
        }
        if kind not in endpoint_map:
            raise ValueError(f"Unsupported Telegram media kind: {kind}")

        if not path:
            raise RuntimeError(
                "Telegram rich media currently requires a local uploaded file. "
                "Use the website/external link field for a normal URL, or upload the media file."
            )

        file_path = Path(path)
        if not file_path.is_file():
            raise FileNotFoundError(f"Media file not found: {path}")

        data = {"chat_id": chat_id}
        if caption:
            data["caption"] = caption

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            with file_path.open("rb") as media_file:
                response = await client.post(
                    f"{self.base_url}/{endpoint_map[kind]}",
                    data=data,
                    files={field_map[kind]: (file_path.name, media_file)},
                )
        return self._check(response)

    async def send_text_and_media(
        self,
        chat_id: str,
        message: str,
        media: list[dict],
        link: str | None = None,
    ) -> dict:
        text = message.strip()
        if link:
            text = f"{text}\n\n{link}" if text else link

        if not media:
            return await self.send_message(chat_id, text)

        results = []
        first = True
        for item in media:
            caption = text if first else ""
            result = await self.send_media(
                chat_id=chat_id,
                kind=item["kind"],
                path=item["path"],
                caption=caption,
            )
            results.append(result)
            first = False

        return results[0] if len(results) == 1 else {"ok": True, "results": results}

    @staticmethod
    def _validate(chat_id: str):
        if not chat_id:
            raise RuntimeError("Telegram destination ID is not configured")
